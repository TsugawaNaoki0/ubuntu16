import re
import MeCab
from collections import Counter
import urllib.request, urllib.error
from bs4 import BeautifulSoup
import csv

# ファイル読み込み
file = r'bocchan.txt'

with open(file) as f:
    text = f.read()

url_url = "https://news.yahoo.co.jp/topics/top-picks"   ### 最後尾はページ番号


html = urllib.request.urlopen(url_url)
soup = BeautifulSoup(html, "html.parser")
aaa = soup.select(".newsFeed")
news_tag = soup.select(".newsFeed_item_title") ###

for i in range(len(news_tag)):
    news_tag[i] = str(news_tag[i])
    news_tag[i] = news_tag[i].replace("<div class=\"newsFeed_item_title\">", "").replace("</div>", "")
    # print(news_tag[i])

# print(news_tag)
print("-----------------------")




class kaiseki_class():
    def kaiseki(self, tag):
        text = tag
        tagger = MeCab.Tagger("-Ochasen")
        result = tagger.parse(text)
        result_lines = result.split('\n')

        result_words = []
        words = []

        for result_line in result_lines:
            result_words.append(re.split('[\t,]', result_line))

        for result_word in result_words:

            if (    result_word[0] not in ('EOS', '')
                and result_word[3] == '名詞-一般'):

                    words.append(result_word[0])
        return words


for i in range(len(news_tag)):
    news_tag[i] = news_tag[i].replace("amp;", "")
    # print(news_tag[i])
    aaa = kaiseki_class()
    bbb = aaa.kaiseki(news_tag[i])
    print(bbb)
