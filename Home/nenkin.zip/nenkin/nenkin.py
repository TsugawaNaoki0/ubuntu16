# 参考サイト　　　https://mponline.sbi-moneyplaza.co.jp/money/retirement/20210714kouseinenkin-zougaku.html


jukyu = 0
jukyu_100 = 0
num = 780900
year = 0
month = 0
month_num = 480



print("社会人として何年目ですか？")
year = input()
print("社会人として何年目ですか？：" + year)
month = int(year) * 12

# print(month)


jukyu = int(num) * int(month) / int(month_num)

jukyu_100 = int(jukyu / 100) * 100

num_4_5 = int(jukyu - jukyu_100)
# print(num_4_5)

# print("@@@ " + str(jukyu) + " @@@")


if (50 < num_4_5):
    jukyu = int(jukyu_100 + 100)
    # print(str(jukyu) + "@@@@")

elif (num_4_5 <= 49):
    jukyu = jukyu_100
    # print(str(jukyu) + "@@")

print(str(year) + "年分納付時点でのあなたの年金受給予定額：" + str(jukyu))
# print(jukyu)
# print(jukyu_100)
