import numpy as np
import matplotlib.pyplot as plt
import sys
import time
import csv
from email.mime.text import MIMEText
import smtplib
import urllib.request, urllib.error
from bs4 import BeautifulSoup
import csv



url = 'https://eagle.5ch.net/test/read.cgi/livejupiter/1666852254'
# save_path = '\savename.csv'
opener = urllib.request.build_opener()
opener.addheaders = [('User-Agent',
                      'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1941.0 Safari/537.36')]

html = urllib.request.install_opener(opener)
# url = "https://eagle.5ch.net/test/read.cgi/livejupiter/1666852254"
print(html)

html = urllib.request.urlopen(url)

# soup = BeautifulSoup(html, "html.parser")

# aaa = soup.select(".title")

# print(aaa)
