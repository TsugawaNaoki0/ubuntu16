
import requests
import re
import datetime
import urllib.request, urllib.error
import csv
import requests
import feedparser
import os
from email.mime.text import MIMEText
import smtplib
import sys
import pymysql
import urllib.request, urllib.error
from bs4 import BeautifulSoup
import csv









url = "http://www.kobe-chuo.gr.jp/"

html = urllib.request.urlopen(url)

soup = BeautifulSoup(html, "html.parser")

data_now = str(soup)
print(data_now)

path = './data/page_data.txt'
# path = '/home/natsukiogawa/sample/quake_data.txt'


f = open(path, 'r', encoding='UTF-8')
data_before = f.read()
# print(data_before)

if (data_before == data_now):
    print("no change")
else:
    print("There are some changes")

    f = open(path, 'w')
    f.write(data_now)  # 何も書き込まなくてファイルは作成されました
    # data_now = list(data_now)

    print("更新がありました。")



f.close()
