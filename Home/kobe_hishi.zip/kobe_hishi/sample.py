f = open('kobe_hishi.html', 'r', encoding='UTF-8')

data = f.read()

# print(data)

for k in range(0,10):
    for i in range(26):
        data = data.replace("%" + str(chr(i+65)) + str(k), "")

for k in range(0,10):
    for i in range(26):
        data = data.replace("%" + str(k) + str(chr(i+65)), "")

for k in range(26):
    for i in range(26):
        data = data.replace("%" + str(chr(k+65)) + str(chr(i+65)), "")

for k in range(26):
    for i in range(26):
        data = data.replace("%" + str(k) + str(i), "")

# data = data.replace("&nbsp;", "")
data = data.replace("<a href=\"", "")
data = data.replace("</a>", "")

for i in range(10):
    data = data.replace("./" + str(i), "")
    data = data.replace("_/" + str(i), "")


data = data.replace("─_", "─")
data = data.replace(" _", "")
data = data.replace("/0", "")
data = data.replace(".\">.", "")
data = data.replace("/\">", "")



print(data)
path_w = 'kobe_hishi.html'

with open(path_w, mode='w') as f:
    f.write(data)

f.close()
