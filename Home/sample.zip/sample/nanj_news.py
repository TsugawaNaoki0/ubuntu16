import numpy as np
import matplotlib.pyplot as plt

class n_news_class():
    def n_news(self, url):
        import urllib.request, urllib.error
        from bs4 import BeautifulSoup
        import csv

        self.url = url
        # url = "https://kabuoji3.com/stock/6501/2019/"
        # URLを指定する
        html = urllib.request.urlopen(url)
        # URLを開く
        soup = BeautifulSoup(html, "html.parser")
        # BeautifulSoup で開く
        # HTMLからニュース一覧に使用しているaタグを絞りこんでいく
        # aaa = soup.select(".")
        news_tag = soup.select(".column-inner") ### wpra-list-template
        # news_tag = soup.select(".newsFeed_item_title") ###
        news_tag_2 = soup.select(".article-title-outer")
        # news_tag_3 = soup.select(".")
        print("@")
        print(news_tag_2)

        """
        for i in range(len(news_tag)):
            news_tag[i] = str(news_tag[i]).replace("<div class=\"newsFeed_item_title\">", "").replace("</div>", "")
        return news_tag
        """


if __name__ == '__main__':
    print("ENTER [x] or [X]")
    z = input()

    if (z == "x" or z == "X"):
        # news_num = 21        ### yahoo の記事が22 番目まである
        key_words = ["大谷", "筒香"]    ### キーワード(複数可)
        hits = []
        # news_books = [[] for j in range(news_num)]
        # theme = ["top-picks", "domestic", "world", "business", "entertainment", "sports", "it", "science", "local"]
        # theme = ["top-picks"]


        # for l in range(len(theme)):

            # for k in range(1, news_num+1):
                # print(theme[l])
        url_url = "http://livejupiter2.net/"
        yyy = n_news_class()
        n_news_data = yyy.n_news(url_url)

                # news_books[k-1] = n_news_data
                # print(news_books[k-1])
                # for i in range(len(n_news_data)):
                    # print(n_news_data[i])





        """

            for n in range(len(key_words)):
                for h in range(len(news_books)):
                    for g in range(len(news_books[h])):
                        ccc = news_books[h][g]
                        # print(news_books[h][g])
                        ddd = ccc.find(key_words[n])
                        if (ddd > -1) :
                            # print(ccc[ddd])
                            hits.append(ccc)

        for t in range(len(hits)):
            print(hits[t])
        """
