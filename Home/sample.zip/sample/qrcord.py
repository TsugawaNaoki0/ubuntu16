import cv2

image = cv2.imread("input/qrCode.png")

qrDetector = cv2.QRCodeDetector()
data,bbox,rectifiedImage = qrDetector.detectAndDecode(image)

print(data)

cv2.imshow("Rectified QRCode", rectifiedImage)

cv2.waitKey(0)
cv2.destroyAllWindows()
