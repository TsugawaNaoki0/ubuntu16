import smtplib
from email.mime.text import MIMEText

TO_ADDRESS = "ogawanatsuki19960701@gmail.com"
FROM_ADDRESS = "jinchuanzhishu76@gmail.com"
MY_PASSWORD = "19960701tsugawa"

def send_mail(msg):
    try:
        smtpobj = smtplib.SMTP('smtp.gmail.com', 587)
        smtpobj.ehlo()
        smtpobj.starttls()
        smtpobj.ehlo()
        smtpobj.login(FROM_ADDRESS, MY_PASSWORD)
        smtpobj.sendmail(FROM_ADDRESS, TO_ADDRESS, msg.as_string())
        smtpobj.close()
        return True
    except:
        return False

if __name__ == '__main__':
    msg = MIMEText("テスト本文")
    msg['Subject'] = "テスト"
    msg['From'] = FROM_ADDRESS
    msg['To'] = TO_ADDRESS

    result = send_mail(msg)
    print(result)
