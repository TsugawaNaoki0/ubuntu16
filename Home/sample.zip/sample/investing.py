import datetime

# 日付けをdatetimeに変換
df["日付け"] = df["日付け"].apply(lambda x: datetime.datetime.strptime(x, "%Y年%m月%d日"))

def number_converter(x):
    # 不要文字を除去
    for s in [",", "M", "%"]:
        x = x.replace(s, "")

    return float(x)

# 数値データを　floatに変換
for col in ["終値", "始値", "高値", "安値", "出来高", "前日比%"]:
    df[col] = df[col].apply(number_converter)
