import numpy as np
import matplotlib.pyplot as plt

print("Hello !!!!!!!!")

tesuu = 0                       # 手数料
zandaka = 100000000                # 残高
zandaka_0 = zandaka
nenritsu = 0.15                 # 年率
nenritsu = 0.3375                 # 年率 to_go
year = 365
month = 1                       # 月数
nissu = 25 + (month-1) * 30
hensai = 1000000
goukei = 0

# month = 100
month = int(zandaka / hensai) - 1


total = []
total_tesuu = []
total_hensai = []
wariai = []
for i in range(month+1):
    tesuu = int(zandaka * nenritsu / 12)
    gan_hensai = hensai * month - tesuu
    # print("手数料: " + str(tesuu))
    print()
    # print("元金の返済額: " + str(gan_hensai))
    zandaka = zandaka - hensai
    print("[" + str(i+1) + "ヶ月目], 返済額： " + str(hensai) + ", 手数料: " + str(tesuu) + ", 残高: " + str(zandaka))
    goukei += (hensai + tesuu)
    total.append(goukei)
    total_tesuu.append(tesuu)
    total_hensai.append((hensai + tesuu))
    if (zandaka <= 0):
        wariai.append(zandaka_0)
    else:
        wariai.append((goukei / zandaka))

print("合計: " + str(goukei))
# print(total)
x = total_tesuu
y = total
z = total_hensai
q = wariai
w = [zandaka_0 for j in range(len(x))]
r = [total[len(total)-1] for d in range(len(x))]
yoko = [(1+i) for i in range(len(x))]

plt.bar(yoko, y) # この場合のplot関数の第一引数xは、x軸に対応し、第二引数のyがy軸にあたります。
plt.plot(yoko, w)
plt.plot(yoko, r)

print("手数料の総額：　" + str(total[len(total)-1] - zandaka_0))
# plt.plot(y) # この場合のplot関数の第一引数xは、x軸に対応し、第二引数のyがy軸にあたります。
# plt.show()
