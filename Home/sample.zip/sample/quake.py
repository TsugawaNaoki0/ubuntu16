import numpy as np
import matplotlib.pyplot as plt
import urllib.request, urllib.error
from bs4 import BeautifulSoup
import csv
import requests
import feedparser
import os



class y_news_class():
    def y_news(self, url):
        self.url = url
        data_bank = []

        feed = feedparser.parse(url)
        for entry in feed.entries:
            data_bank.append(entry.title)
            data_bank.append(entry.link)
            # print('タイトル:', entry.title)
            # print('URL:', entry.link)
        return data_bank

if __name__ == '__main__':
    url = "https://headline.5ch.net/bbynamazu/news.rss"

    aaa = y_news_class()
    bbb = aaa.y_news(url)

    # for i in range(len(bbb)):
    #     print(bbb[i])

    bbb = str(bbb)
    data_now = bbb




    f = open('./data/quake_data.txt', 'r', encoding='UTF-8')
    data_before = f.read()
    # print(data_before)

    if (data_before == data_now):
        print("no change")
    else:
        print("There are some changes")

        path = './data/quake_data.txt'
        f = open(path, 'w')
        f.write(data_now)  # 何も書き込まなくてファイルは作成されました
        news = data_now[0]
        print(news)
    # print(data)



    f.close()






    path = './data/quake_data.txt'
    f = open(path, 'w')
    f.write(bbb)  # 何も書き込まなくてファイルは作成されました
    f.close()

    # print(bbb)
