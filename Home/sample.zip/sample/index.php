<html>
    <head>
        <title>Running a Python script</title>
        <?PHP
        // echo shell_exec("python3 script.py");
        echo shell_exec("python3 revolving.py");
        ?>
        </head>
    <body>
        <!-- BODY -->
    </body>
</html>
