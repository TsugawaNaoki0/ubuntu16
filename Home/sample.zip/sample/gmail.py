from email.mime.text import MIMEText
import smtplib



class quake_mail_class():
    def quake_mail(self, quake_news):

        # SMTP認証情報
        account = "subaodezhen641@gmail.com"
        # password = "19960701jishin"
        password = "ubqrmyfjgxsojiwg"

        # 送受信先
        to_email = "jinchuanzhishu76@gmail.com"
        from_email = "subaodezhen641@gmail.com"

        # MIMEの作成
        subject = "地震速報"
        # message = "地震速報"
        message = quake_news
        msg = MIMEText(message, "html")
        msg["Subject"] = subject
        msg["To"] = to_email
        msg["From"] = from_email

        # メール送信処理
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(account, password)
        server.send_message(msg)
        server.quit()

if __name__ == '__main__':
    news = "地震が起きました"
    aaa = quake_mail_class()
    bbb = aaa.quake_mail(news)
