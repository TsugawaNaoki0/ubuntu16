a = 2000
b = 21
print("a = " + str(a))
print("b = " + str(b))
print("a + b = " + str(a + b) + "")
