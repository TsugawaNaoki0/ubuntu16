import pymysql

connection = pymysql.connect(host='localhost', user='root', password='19960701mysql', db='mail_list')

try:
    with connection.cursor() as cursor:
        # sql = "INSERT INTO sample_tbl (id, firstname, lastname) VALUES (1, 'mars', 'quai');"
        sql = "select email from mailDeta;"
        cursor.execute(sql)
        sql = "select email from mailDeta;"
        cursor.execute(sql)
        sql = "select email from mailDeta;"
        cursor.execute(sql)
        sql = "select email from mailDeta;"
        cursor.execute(sql)



        connection.commit()

finally:
    connection.close()
