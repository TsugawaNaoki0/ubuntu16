import qrcode
import socket
import sys


print("hello ")
mail = str(sys.argv[1])
print(mail)

img = qrcode.make('https://5ch.net/')
ip_address = socket.gethostbyname(socket.gethostname())
print(ip_address)
# print(type(img))
# print(img.size)
# <class 'qrcode.image.pil.PilImage'>
# (290, 290)

# img.save('./qrcode_test.png')
