import os
import subprocess

hitachiGroup = "h_日立グループ"

hi = "日立製作所"
hisys = "日立システムズ"
ho_hisys = "北海道日立システムズ"
shi_hisys = "四国日立システムズ"
kyu_hisys = "九州日立システムズ"
hisys_es = "日立システムズエンジニアリングサービス"
hisys_fs = "日立システムズフィールドサービス"
hisys_ps = "日立システムズパワーサービス"
secure_brain = "セキュアブレイン"
hi_energy = "日立エナジー"
hi_astemo = "日立Astemo"
hi_kenki = "日立建機"
hisol = "日立ソリューションズ"
hbs = "日立ビルシステム"
hbs_engineering = "日立ビルシステムエンジニアリング"
hi_academy = "日立アカデミー"
hi_hitech = "日立ハイテク"
hi_hitech_sol = "日立ハイテクソリューションズ"
hi_hitech_nexus = "日立ハイテクソリューションズ"
hi_hitech_support = "日立ハイテクソリューションズ"
gd_japan = "ギーゼッケ・アンド・デブリエント"
hi_hitech_field = "日立ハイテクソリューションズ"
hi_hitech_fineSys = "日立ハイテクファインシステムズ"
hi_hitech_manuSer = "日立ハイテクマニファクチャ&サービス"
hi_hitech_science = "日立ハイテクサイエンス"
hi_hitech_kyu = "日立ハイテク九州"
hi_hitech_cca = "Chous Call Asia"
neu = "NeU"



subprocess.run(["mkdir", hitachiGroup])

subprocess.run(["mkdir", hitachiGroup + "/" +  hi])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hisys])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hisys + "/" + ho_hisys])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hisys + "/" + shi_hisys])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hisys + "/" + kyu_hisys])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hisys + "/" + hisys_es])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hisys + "/" + hisys_fs])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hisys + "/" + hisys_ps])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hisys + "/" + secure_brain])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hi_energy])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hi_academy])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hi_astemo])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hi_kenki])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hisol])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hbs])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hbs + "/" + hbs_engineering])

subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hi_hitech])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hi_hitech + "/" + hi_hitech_sol])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hi_hitech + "/" + hi_hitech_nexus])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hi_hitech + "/" + hi_hitech_support])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hi_hitech + "/" + gd_japan])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hi_hitech + "/" + hi_hitech_field])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hi_hitech + "/" + hi_hitech_fineSys])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hi_hitech + "/" + hi_hitech_manuSer])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hi_hitech + "/" + hi_hitech_science])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hi_hitech + "/" + hi_hitech_kyu])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hi_hitech + "/" + hi_hitech_cca])
subprocess.run(["mkdir", hitachiGroup + "/" +  hi + "/" + hi_hitech + "/" + neu])
hi_hitech = "日立ハイテク"
hi_hitech_sol = "日立ハイテクソリューションズ"
hi_hitech_nexus = "日立ハイテクソリューションズ"
hi_hitech_support = "日立ハイテクソリューションズ"
gd_japan = "ギーゼッケ・アンド・デブリエント"
hi_hitech_field = "日立ハイテクソリューションズ"
hi_hitech_fineSys = "日立ハイテクファインシステムズ"
hi_hitech_manuSer = "日立ハイテクマニファクチャ&サービス"
hi_hitech_science = "日立ハイテクサイエンス"
hi_hitech_kyu = "日立ハイテク九州"
hi_hitech_cca = "Chous Call Asia"
neu = "NeU"



di_list = os.listdir(path='./' + hitachiGroup)
print()
print()
print()
for i in range(len(di_list)):
    print(di_list[i])




# subprocess.run(["tree"])


# subprocess.run(["tree"])
