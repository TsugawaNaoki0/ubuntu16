import os
import subprocess

asahiGroup = "a_朝日新聞社"
shachou = "代表取締役社長"
joumuTorishimari = "常務取締役"
torishimari = "取締役"
joukinKansa = "常勤監査役"
kansa = "監査役"
joumuShikkou = "常務執行役員"
shikkou = "執行役員"
hokkaidouShishachou = "北海道支社長"
ronsetsu = "論説主幹"
kikaku = "企画事業担当兼企画事業本部長"
jouhou = "情報技術担当兼情報技術本部長"


subprocess.run(["mkdir", asahiGroup])

subprocess.run(["mkdir", asahiGroup + "/00_" + shachou])
f = open("./" + asahiGroup + "/00_" + shachou + "/" + "中村史郎", "w")

subprocess.run(["mkdir", asahiGroup + "/01_" + joumuTorishimari])
f = open("./" + asahiGroup + "/01_" + joumuTorishimari + "/" + "小西勝英（プリントメディア事業統括／東京本社代表）", "w")
f = open("./" + asahiGroup + "/01_" + joumuTorishimari + "/" + "堀江隆（経営戦略統括／グループ・ネットワーク政策統括）", "w")
f = open("./" + asahiGroup + "/01_" + joumuTorishimari + "/" + "角田克（コンテンツ・デジタル政策統括／編集担当）", "w")

subprocess.run(["mkdir", asahiGroup + "/02_" + torishimari])
f = open("./" + asahiGroup + "/02_" + torishimari + "/" + "小林剛（大阪本社代表）", "w")
f = open("./" + asahiGroup + "/02_" + torishimari + "/" + "岡本順（総務・人材政策統括／管理・労務／コンプライアンス担当）", "w")
f = open("./" + asahiGroup + "/02_" + torishimari + "/" + "堀越礼子（事業・商品開発統括／イベント戦略担当）", "w")
f = open("./" + asahiGroup + "/02_" + torishimari + "/" + "藤ノ木正哉", "w")

subprocess.run(["mkdir", asahiGroup + "/03_" + joukinKansa])
f = open("./" + asahiGroup + "/03_" + joukinKansa + "/" + "永江正幸", "w")
f = open("./" + asahiGroup + "/03_" + joukinKansa + "/" + "坂本弘子", "w")

subprocess.run(["mkdir", asahiGroup + "/04_" + kansa])
f = open("./" + asahiGroup + "/04_" + kansa + "/" + "安田隆二", "w")
f = open("./" + asahiGroup + "/04_" + kansa + "/" + "金子圭子", "w")
f = open("./" + asahiGroup + "/04_" + kansa + "/" + "足立直樹", "w")

subprocess.run(["mkdir", asahiGroup + "/05_" + joumuShikkou])
f = open("./" + asahiGroup + "/05_" + joumuShikkou + "/" + "大西弘美（技術統括（ＣＴＯ）／国際担当）", "w")
f = open("./" + asahiGroup + "/05_" + joumuShikkou + "/" + "宍道学（組織・機構改革統括／不動産担当）", "w")
f = open("./" + asahiGroup + "/05_" + joumuShikkou + "/" + "金山達也（顧客開発・データ戦略統括／出版担当）", "w")
f = open("./" + asahiGroup + "/05_" + joumuShikkou + "/" + "小田切則雄（販売戦略／教育事業担当）", "w")
f = open("./" + asahiGroup + "/05_" + joumuShikkou + "/" + "清水隆（財務担当兼財務本部長）", "w")

subprocess.run(["mkdir", asahiGroup + "/06_" + shikkou])
f = open("./" + asahiGroup + "/06_" + shikkou + "/" + "福島繁（広報／ジェンダープロジェクト／環境担当）", "w")
f = open("./" + asahiGroup + "/06_" + shikkou + "/" + "尾形俊三（製作担当）", "w")
f = open("./" + asahiGroup + "/06_" + shikkou + "/" + "佐古浩敏（名古屋本社代表）", "w")
f = open("./" + asahiGroup + "/06_" + shikkou + "/" + "大滝敏之（西部本社代表）", "w")
f = open("./" + asahiGroup + "/06_" + shikkou + "/" + "岡村邦則（人材戦略・働き方改革担当兼人材戦略本部長兼人材マネジメント室長）", "w")
f = open("./" + asahiGroup + "/06_" + shikkou + "/" + "高田圭子（ＣＳＲ担当）", "w")
f = open("./" + asahiGroup + "/06_" + shikkou + "/" + "山盛英司（マーケティング担当兼マーケティング戦略本部長）", "w")
f = open("./" + asahiGroup + "/06_" + shikkou + "/" + "高野健一（デジタル事業／知的財産担当）", "w")
f = open("./" + asahiGroup + "/06_" + shikkou + "/" + "神戸久（メディアビジネス担当）", "w")
f = open("./" + asahiGroup + "/06_" + shikkou + "/" + "長谷川玲（経営企画・メディア戦略担当兼経営企画室長兼社長補佐役）", "w")
f = open("./" + asahiGroup + "/06_" + shikkou + "/" + "宮田喜好（ゼネラルマネジャー兼東京本社編集局長）", "w")

subprocess.run(["mkdir", asahiGroup + "/07_" + hokkaidouShishachou])
f = open("./" + asahiGroup + "/07_" + hokkaidouShishachou + "/" + "山崎靖", "w")

subprocess.run(["mkdir", asahiGroup + "/08_" + ronsetsu])
f = open("./" + asahiGroup + "/08_" + ronsetsu + "/" + "根本清樹", "w")

subprocess.run(["mkdir", asahiGroup + "/09_" + kikaku])
f = open("./" + asahiGroup + "/09_" + kikaku + "/" + "花畑和宏", "w")

subprocess.run(["mkdir", asahiGroup + "/10_" + jouhou])
f = open("./" + asahiGroup + "/10_" + jouhou + "/" + "西丸玄", "w")



f.close()


print()
print()
print()
print()

di_list = os.listdir(path='./' + asahiGroup)
print(asahiGroup)
# print(di_list)
print()
for i in range(len(di_list)):
    print(di_list[i])
    for k in range(len(di_list[i])):
        print(di_list[[i][k]])
# subprocess.run(["tree"])
