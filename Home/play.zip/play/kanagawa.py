import os
import subprocess

kanagawaKen = "k_神奈川県"
yokohama = "横浜市"
kawasaki = "川崎市"
yokosuka = "横須賀市"
kamakura = "鎌倉市"
zushi = "逗子市"
miura = "三浦市"
sagamihara = "相模原市"
atsugi = "厚木市"
yamato = "大和市"
ebina = "海老名市"
zama = "座間市"
ayase = "綾瀬市"
hiratsuka = "平塚市"
fujisawa = "藤沢市"
chigasaki = "茅ヶ崎市"
hadano = "秦野市"
isehara = "伊勢原市"
odawara = "小田原市"
minamiashigara = "南足柄市"
tsurumi = "鶴見区"
kanagawa = "神奈川区"
nishi = "西区"
naka = "中区"
minami_y = "南区"
hodogaya = "保土ヶ谷区"
isogo = "磯子区"
kanazawa = "金沢区"
kouhoku = "港北区"
totsuka = "戸塚区"
kounan = "港南区"
asahi = "旭区"
midori_y = "緑区"
seya = "瀬谷区"
sakae = "栄区"
izumi = "泉区"
aoba = "青葉区"
tsuduki = "都筑区"
kawasaki = "川崎区"
saiwai = "幸区"
nakahara = "中原区"
takatsu = "高津区"
tama = "多摩区"
miyamae = "宮前区"
asao = "麻生区"
midori_s = "緑区"
chuou = "中央区"
minami_s = "南区"
miura_g = "三浦郡"
kouza_g = "高座郡"
naka_g = "中郡"
ashigarakami_g = "足柄上郡"
ashigarashimo_g = "足柄下郡"
aikou_g = "愛甲郡"




subprocess.run(["mkdir", kanagawaKen])

subprocess.run(["mkdir", kanagawaKen + "/" + yokohama])
subprocess.run(["mkdir", kanagawaKen + "/" + kawasaki])
subprocess.run(["mkdir", kanagawaKen + "/" + yokosuka])
subprocess.run(["mkdir", kanagawaKen + "/" + kamakura])
subprocess.run(["mkdir", kanagawaKen + "/" + zushi])
subprocess.run(["mkdir", kanagawaKen + "/" + miura])
subprocess.run(["mkdir", kanagawaKen + "/" + sagamihara])
subprocess.run(["mkdir", kanagawaKen + "/" + atsugi])
subprocess.run(["mkdir", kanagawaKen + "/" + yamato])
subprocess.run(["mkdir", kanagawaKen + "/" + ebina])
subprocess.run(["mkdir", kanagawaKen + "/" + zama])
subprocess.run(["mkdir", kanagawaKen + "/" + ayase])
subprocess.run(["mkdir", kanagawaKen + "/" + hiratsuka])
subprocess.run(["mkdir", kanagawaKen + "/" + fujisawa])
subprocess.run(["mkdir", kanagawaKen + "/" + chigasaki])
subprocess.run(["mkdir", kanagawaKen + "/" + hadano])
subprocess.run(["mkdir", kanagawaKen + "/" + isehara])
subprocess.run(["mkdir", kanagawaKen + "/" + odawara])
subprocess.run(["mkdir", kanagawaKen + "/" + minamiashigara])





di_list = os.listdir(path='./' + kanagawa)
print()
print()
print()
for i in range(len(di_list)):
    print(di_list[i])




# subprocess.run(["tree"])


# subprocess.run(["tree"])
