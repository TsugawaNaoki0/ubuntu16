import os
import subprocess

mitsubishiGroup = "m_三菱グループ"
mi_cemicalHoldings = "三菱ケミカルホールディングス"
mi_jisho = "三菱地所"
mi_jidousha = "三菱自動車工業"
mi_jukou = "三菱重工業"
mi_shouji = "三菱商事"
mi_seikou = "三菱製鋼"
mi_seishi = "三菱製紙"
mi_souko = "三菱倉庫"
mi_souken = "三菱総合研究所"
mi_denki = "三菱電機"
mi_ufjBank = "三菱UFJ銀行"
mi_fusouTrackBuss = "三菱ふそうトラック・バス"
mi_material = "三菱マテリアル"
mi_uflShoukenHoldings = "三菱UFJ証券ホールディングス"
mi_uflShintakuBank = "三菱UFJ信託銀行"
agc = "AGC"
kirinHoldings = "キリンホールディングス"
eneosHoldings = "ENEOSホールディングス"
tokyoKaijhoNichidouKasaihoken = "東京海上日動火災保険"
japanYusen = "日本郵船"
ps_mi = "ピーエス三菱"
meijiYasudaSeimei = "明治安田生命保険"
mi_cemical = "三菱ケミカル"
mi_autoLease = "三菱オートリース"
mi_kousekiYusou = "三菱鉱石輸送"
mi_shokuhin = "三菱食品"
mi_spaceSoftware = "三菱スペースソフトウェア"
mi_precision = "三菱プレシジョン"
mi_ufjNicos = "三菱UFJニコス"
mi_hcCapital = "三菱HCキャピタル"
astomosEnergy = "アストモスエナジー"
daiNipponTosou = "大日本塗装"
niponTataConsaltancyServicies = "日本タタ・コンサルタンシー・サービシズ"
lawson = "ローソン"
mi_alminium = "三菱アルミニウム"
mi_kakouki = "三菱化工機"
mi_gassbio = "三菱ガス化学"
nittoFujiSeifun = "日東富士製粉"
nipponCareSupply = "日本ケアサプライ"
nipponShokuhinKakou = "日本食品加工"
chiyodaKakouKensetsu = "千代田化工建設"
chuouKagaku = "中央化学"




subprocess.run(["mkdir", mitsubishiGroup + "/"])

subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_gassbio])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_kakouki])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_cemical])
subprocess.run(["mkdir", mitsubishiGroup + "/" + meijiYasudaSeimei])
subprocess.run(["mkdir", mitsubishiGroup + "/" + ps_mi])
subprocess.run(["mkdir", mitsubishiGroup + "/" + japanYusen])
subprocess.run(["mkdir", mitsubishiGroup + "/" + tokyoKaijhoNichidouKasaihoken])
subprocess.run(["mkdir", mitsubishiGroup + "/" + eneosHoldings])
subprocess.run(["mkdir", mitsubishiGroup + "/" + kirinHoldings])
subprocess.run(["mkdir", mitsubishiGroup + "/" + agc])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_uflShintakuBank])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_uflShoukenHoldings])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_material])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_fusouTrackBuss])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_alminium])
subprocess.run(["mkdir", mitsubishiGroup + "/" + niponTataConsaltancyServicies])
subprocess.run(["mkdir", mitsubishiGroup + "/" + daiNipponTosou])
subprocess.run(["mkdir", mitsubishiGroup + "/" + astomosEnergy])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_hcCapital])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_ufjNicos])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_precision])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_spaceSoftware])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_shokuhin])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_kousekiYusou])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_ufjBank])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_denki])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_souken])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_souko])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_seishi])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_seikou])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_jukou])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_jidousha])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_jisho])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_cemicalHoldings])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_shouji])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_shouji + "/" + nittoFujiSeifun])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_shouji + "/" + nipponCareSupply])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_shouji + "/" + nipponShokuhinKakou])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_shouji + "/" + chiyodaKakouKensetsu])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_shouji + "/" + chuouKagaku])
subprocess.run(["mkdir", mitsubishiGroup + "/" + mi_shouji + "/" + lawson])

di_list = os.listdir(path='./' + mitsubishiGroup)
# print(di_list)
print()
print()
print()
for i in range(len(di_list)):
    print(di_list[i])
# subprocess.run(["tree"])
