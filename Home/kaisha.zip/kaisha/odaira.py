import subprocess

hi = "日立製作所"
hisys = "日立システムズ"
ho_hisys = "北海道日立システムズ"
shi_hisys = "四国日立システムズ"
kyu_hisys = "九州日立システムズ"
hisys_es = "日立システムズエンジニアリングサービス"
hisys_fs = "日立システムズフィールドサービス"
hisys_ps = "日立システムズパワーサービス"
secure_brain = "セキュアブレイン"
hi_energy = "日立エナジー"
hi_astemo = "日立Astemo"
hi_kenki = "日立建機"
hisol = "日立ソリューションズ"
hbs = "日立ビルシステム"
hbs_engineering = "日立ビルシステムエンジニアリング"
hi_academy = "日立アカデミー"


subprocess.run(["mkdir", hi])
subprocess.run(["mkdir", hi + "/" + hisys])
subprocess.run(["mkdir", hi + "/" + hisys + "/" + ho_hisys])
subprocess.run(["mkdir", hi + "/" + hisys + "/" + shi_hisys])
subprocess.run(["mkdir", hi + "/" + hisys + "/" + kyu_hisys])
subprocess.run(["mkdir", hi + "/" + hisys + "/" + hisys_es])
subprocess.run(["mkdir", hi + "/" + hisys + "/" + hisys_fs])
subprocess.run(["mkdir", hi + "/" + hisys + "/" + hisys_ps])
subprocess.run(["mkdir", hi + "/" + hisys + "/" + secure_brain])

subprocess.run(["mkdir", hi + "/" + hi_energy])
subprocess.run(["mkdir", hi + "/" + hi_academy])
subprocess.run(["mkdir", hi + "/" + hi_astemo])
subprocess.run(["mkdir", hi + "/" + hi_kenki])
subprocess.run(["mkdir", hi + "/" + hisol])
subprocess.run(["mkdir", hi + "/" + hbs])
subprocess.run(["mkdir", hi + "/" + hbs + "/" + hbs_engineering])
