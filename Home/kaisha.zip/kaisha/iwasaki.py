import subprocess

mi_cemicalHoldings = "三菱ケミカルホールディングス"
mi_jisho = "三菱地所"
mi_jidousha = "三菱自動車工業"
mi_jukou = "三菱重工業"
mi_shouji = "三菱商事"
mi_seikou = "三菱製鋼"
mi_seishi = "三菱製紙"
mi_souko = "三菱倉庫"
mi_souken = "三菱総合研究所"
mi_denki = "三菱電機"
mi_ufjBank = "三菱UFJ銀行"
mi_fusouTrackBuss = "日立ビルシステムエンジニアリング"
mi_material = "三菱マテリアル"
mi_uflShoukenHoldings = "三菱UFJ証券ホールディングス"
mi_uflShintakuBank = "三菱UFJ証券ホールディングス"
agc = "日立アカデミー"
kirinHoldings = "キリンホールディングス"
eneosHoldings = "ENEOSホールディングス"
tokyoKaijhoNichidouKasaihoken = "東京海上日動火災保険"
japanYusen = "日本郵船"
ps_mi = "ピーエス三菱"
meijiYasudaSeimei = "明治安田生命保険"
mi_cemical = "三菱ケミカル"
mi_autoLease = "三菱オートリース"
mi_kousekiYusou = "三菱鉱石輸送"
mi_shokuhin = "三菱食品"
mi_spaceSoftware = "三菱スペースソフトウェア"
mi_precision = "三菱プレシジョン"
mi_ufjNicos = "三菱UFJニコス"
mi_hcCapital = "三菱HCキャピタル"
astomosEnergy = "アストモスエナジー"
daiNipponTosou = "大日本塗装"
niponTataConsaltancyServicies = "日本タタ・コンサルタンシー・サービシズ"
lawson = "ローソン"
mi_alminium = "三菱アルミニウム"
mi_kakouki = "三菱化工機"
mi_gassbio = "三菱ガス化学"






subprocess.run(["mkdir", "三菱グループ/" + mi_gassbio])
subprocess.run(["mkdir", "三菱グループ/" + mi_kakouki])

subprocess.run(["mkdir", "三菱グループ/" + mi_cemical])
subprocess.run(["mkdir", "三菱グループ/" + meijiYasudaSeimei])
subprocess.run(["mkdir", "三菱グループ/" + ps_mi])
subprocess.run(["mkdir", "三菱グループ/" + japanYusen])
subprocess.run(["mkdir", "三菱グループ/" + tokyoKaijhoNichidouKasaihoken])
subprocess.run(["mkdir", "三菱グループ/" + eneosHoldings])
subprocess.run(["mkdir", "三菱グループ/" + kirinHoldings])
subprocess.run(["mkdir", "三菱グループ/" + agc])
subprocess.run(["mkdir", "三菱グループ/" + mi_uflShintakuBank])
subprocess.run(["mkdir", "三菱グループ/" + mi_uflShoukenHoldings])
subprocess.run(["mkdir", "三菱グループ/" + mi_material])
subprocess.run(["mkdir", "三菱グループ/" + mi_fusouTrackBuss])

subprocess.run(["mkdir", "三菱グループ/" + mi_alminium])
subprocess.run(["mkdir", "三菱グループ/" + lawson])
subprocess.run(["mkdir", "三菱グループ/" + niponTataConsaltancyServicies])
subprocess.run(["mkdir", "三菱グループ/" + daiNipponTosou])
subprocess.run(["mkdir", "三菱グループ/" + astomosEnergy])
subprocess.run(["mkdir", "三菱グループ/" + mi_hcCapital])
subprocess.run(["mkdir", "三菱グループ/" + mi_ufjNicos])
subprocess.run(["mkdir", "三菱グループ/" + mi_precision])
subprocess.run(["mkdir", "三菱グループ/" + mi_spaceSoftware])
subprocess.run(["mkdir", "三菱グループ/" + mi_shokuhin])
subprocess.run(["mkdir", "三菱グループ/" + mi_kousekiYusou])
subprocess.run(["mkdir", "三菱グループ/" + mi_ufjBank])
subprocess.run(["mkdir", "三菱グループ/" + mi_denki])
subprocess.run(["mkdir", "三菱グループ/" + mi_souken])
subprocess.run(["mkdir", "三菱グループ/" + mi_souko])
subprocess.run(["mkdir", "三菱グループ/" + mi_seishi])
subprocess.run(["mkdir", "三菱グループ/" + mi_seikou])
subprocess.run(["mkdir", "三菱グループ/" + mi_shouji])
subprocess.run(["mkdir", "三菱グループ/" + mi_jukou])
subprocess.run(["mkdir", "三菱グループ/" + mi_jidousha])
subprocess.run(["mkdir", "三菱グループ/" + mi_jisho])
subprocess.run(["mkdir", "三菱グループ/" + mi_cemicalHoldings])
