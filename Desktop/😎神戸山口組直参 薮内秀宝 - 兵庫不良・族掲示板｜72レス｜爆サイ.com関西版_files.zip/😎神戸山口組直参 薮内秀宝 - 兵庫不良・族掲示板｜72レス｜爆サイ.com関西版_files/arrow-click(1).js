/*
 * arrow jQuery
 */

// 矢印ボタン ドラッグ 表示／非表示
$(".scroll-box").on("scroll", function () {
    var scrollPosition = $(".scroll-box").scrollLeft();
    var maxPostion = Math.floor($('.scroll-box').get(0).scrollWidth - $('.scroll-box').get(0).clientWidth - 1);
    if (scrollPosition <= 0) {
        $(".arrow-left").css("visibility", "hidden");
    } else {
        $(".arrow-left").css("visibility", "visible");
    }
    if (scrollPosition >= maxPostion) {
        $(".arrow-right").css("visibility", "hidden");
    } else {
        $(".arrow-right").css("visibility", "visible");
    }
});

// 矢印ボタン 押下 表示／非表示
$(".arrow-left").on("click", function () {
    var scrollPosition = $(".scroll-box").scrollLeft();
    if (scrollPosition > 0) {
        $(".scroll-box").scrollLeft(scrollPosition - 80);
        return;
    };
    $(".scroll-box").scrollLeft(0);
});
$(".arrow-right").on("click", function () {
    var scrollPosition = $(".scroll-box").scrollLeft();
    var maxPostion = $('.scroll-box').get(0).scrollWidth - $('.scroll-box').get(0).clientWidth;
    if (scrollPosition < maxPostion) {
        $(".scroll-box").scrollLeft(scrollPosition + 80);
        return;
    };
    $(".scroll-box").scrollLeft(maxPostion);
});
