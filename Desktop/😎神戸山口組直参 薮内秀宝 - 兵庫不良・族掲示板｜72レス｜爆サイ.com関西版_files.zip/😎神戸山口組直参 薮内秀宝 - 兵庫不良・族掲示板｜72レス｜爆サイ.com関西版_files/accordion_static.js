/*!
アコーディオン形式の開閉パネル
2017/05/02 Create 
*/
/*
$(function(){

  $('.accordion_static').on('click' , '.accordion-control', function(e){
    e.preventDefault();

    // 現在のアイコン状態で＋にするか-にするか判定
    if($(this).children('i').is('.fa-minus')){

      // ＋アイコンに変更
      $(this).children('i')
        .removeClass()
        .addClass('fa fa-plus');

    }else{

      // -アイコンに変更
      $(this).children('i')
        .removeClass()
        .addClass('fa fa-minus');

    }

    // クリックしたリストの開閉
    $(this)
      .next('.accordion-panel')
      .slideToggle();

  });

});
*/
/*
$(function(){
	$(".accordionbox_static dt").on("click", function() {
		$(this).next().slideToggle();	
		// activeが存在する場合
		if ($(this).children(".accordion_static_icon").hasClass('active')) {
			// activeを削除
			$(this).children(".accordion_static_icon").removeClass('active');
		}
		else {
			// activeを追加
			$(this).children(".accordion_static_icon").addClass('active');
		}
	});
});
*/


$(function(){
	$(".accordionbox_static dt").on("click", function() {
        $(".accordionbox_static dt").not(this).next().slideUp(300);
        $(".accordionbox_static dt").not(this).children(".accordion_static_icon, .subject_rule").removeClass('active');
		$(this).next().slideToggle();
		// activeが存在する場合
		if ($(this).children(".accordion_static_icon, .subject_rule").hasClass('active')) {
			// activeを削除
			$(this).children(".accordion_static_icon, .subject_rule").removeClass('active');
		}
		else {
			// activeを追加
			$(this).children(".accordion_static_icon, .subject_rule").addClass('active');
		}
	});
});
