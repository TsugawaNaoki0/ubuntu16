// 当該スレッドが削除依頼を受けている場合のみ実行
if ($('input:hidden[name="admin_delete_btn"]').val()) {
	if (typeof window.localStorage !== 'undefined') {
		// ローカルストレージから値を取得（チェック数も取得）
		let delData = (localStorage.getItem("del_multi")) ? JSON.parse(localStorage.getItem("del_multi")) : [];
		let checkNum = (delData) ? delData.length : 0;
		let obj = $('[name="delCheck[]"]');

		// ローカルストレージに値が有る場合「一括削除依頼」を表示
		if (checkNum > 0) $("#multi_delete_button").show();

		for (let i = 0 ; i < obj.length ; i++) {
			// ローカルストレージに現在表示中のスレッド・レスのデータが有る場合、チェックを入れる
			if ($.inArray(obj[i].value, delData) >= 0) {
				if (obj[i].value == thr_bbs_bid + "_" + thr_thread_tid + "_0") {
					// スレッドにチェックが有る場合、配下のレスへのチェックを不可とする
					$("[id^=" + thr_bbs_bid + "_" + thr_thread_tid + "_]").prop("disabled", true);
					$("#" + thr_bbs_bid + "_" + thr_thread_tid + "").prop('checked', true);
				} else {
					$("#" + obj[i].value).prop('checked', true);
				}
			}
		}

		// 「一括削除依頼」チェックボックス操作時
		$('[name="delCheck[]"]').change(function() {
			if (checkNum == 50) {
				// チェック数が50個に達している場合、アラートを表示（チェックは入れられない）
				alert("1度に一括削除可能なのは、スレッド・レス合わせて50件です");

				if ($(this).val() == thr_bbs_bid + "_" + thr_thread_tid + "_0") {
					$("#" + thr_bbs_bid + "_" + thr_thread_tid + "").prop('checked', false);
				} else {
					$("#" + $(this).val()).prop('checked', false);
				}
			} else {
				if ($(this).prop("checked")) {
					// スレッドにチェックが入った場合、配下のレスへのチェックを不可とする
					if ($(this).val() == thr_bbs_bid + "_" + thr_thread_tid + "_0") {
						$("[id^=" + thr_bbs_bid + "_" + thr_thread_tid + "_]").prop("disabled", true);
					}

					// チェックされたデータをローカルストレージに追加 ＆ チェック数1増加
					delData[checkNum] = $(this).val();
					localStorage.setItem("del_multi", JSON.stringify(delData, undefined, 1));
					checkNum++;

					// 「一括削除依頼」を表示
					$("#multi_delete_button").show();
				} else {
					// スレッドのチェックが外れた場合、配下のレスへのチェックを可とする
					if ($(this).val() == thr_bbs_bid + "_" + thr_thread_tid + "_0") {
						$("[id^=" + thr_bbs_bid + "_" + thr_thread_tid + "_]").prop("disabled", false);
					}

					// チェックが外れたデータをローカルストレージから削除 ＆ チェック数1減少
					var idx = $.inArray($(this).val(), delData);
					if (idx >= 0) delData.splice(idx, 1);
					localStorage.setItem("del_multi", JSON.stringify(delData, undefined, 1));
					checkNum--;

					// チェック数が0になった場合「一括削除依頼」を非表示
					if (checkNum == 0) $("#multi_delete_button").hide();
				}
			}
		});
	} else {
		alert("このブラウザはlocalStorage非対応のため、一括削除依頼処理の実行は不可です。");
	}
}

//スクロールを固定
function bodyFixedOn() {
	$('body').css('overflow-x', 'hidden'); // 本文の縦スクロールを無効
	$('body').css('overflow-y', 'hidden'); // 本文の縦スクロールを無効
}

//スクロールの固定を解除
function bodyFixedOff() {
	$('body').css('overflow-x','auto'); // 本文の縦スクロールを有効
	$('body').css('overflow-y','auto'); // 本文の縦スクロールを有効
}

// 一括削除依頼Modalを開く
function multiDelete() {
	// ローカルストレージから値を取得
	let delData = JSON.parse(localStorage.getItem("del_multi"));

	// 一括削除依頼Modalを開く
	$(".js-modal-close").addClass("close_delete_multi");
	$(".modal__content").children("#content__delete_multi").toggle(true);
	$.ajax({
		url: "/del_req0_multi/",
		type: "POST",
		data: {
			"delData": delData
		},
		dataType: "html",
	})
	.done(function(data) {
		$("#content__delete_multi").html($("#delete_multi", data).html());
		$(".js-modal").fadeIn();
		bodyFixedOn();
	})
	.fail(function(data) {
		alert("問題がありました。");
	});
	return false;
}

// 一括削除依頼Modalを閉じる
$(".js-modal-close").on("click", function() {
	var fadeOutDone = $(".js-modal").fadeOut();
	var thisBtn = $(this);

	$.when(fadeOutDone).done(function() {
		if (thisBtn.hasClass("close_delete_multi")) {
			$(".modal__content").children("#content__delete_multi").toggle(false);
			thisBtn.removeClass("close_delete_multi");
		}
	});
	bodyFixedOff();
	return false;
});

// 一括削除依頼Modalの「削除依頼送信」を押下
function sendMultiDelete() {
	// バリデーションチェック（通報区分）
	if ($('input:radio[name="q3"]:checked').val() == "") {
		alert("通報区分は必須選択です");

		return false;
	}

	// バリデーションチェック（削除依頼内容）
	if ($('textarea[name="delete_reason"]').val() == "") {
		alert("削除依頼内容は必須入力です");

		return false;
	} else {
		if ($('textarea[name="delete_reason"]').val().length > 750) {
			alert("削除依頼内容は750文字以下で入力してください");

			return false;
		}
	}

	// 一括削除依頼処理実行
	$(".modal_loading").toggle(true);
	$.ajax({
		url : "/del_req1_multi/",
		type : "POST",
		data : $("form[name='delMultiForm']").serializeArray(),
		success : function(data) {
			if (data == "success") {
				localStorage.removeItem("del_multi");
				location.reload();
			} else if (data == "error01") {
				// 削除依頼の荒らしの場合
				alert("ログイン中のアカウントは規制対象です");
				$(".modal_loading").toggle(false);
			} else if (data == "error02") {
				// 特定のアドレスからの削除依頼の場合
				alert("ログイン中のアカウントでは削除依頼が出せません");
				$(".modal_loading").toggle(false);
			} else if (data == "error03") {
				// 削除済のレスに削除依頼が有った場合
				alert("削除依頼されたレス番号は存在しません");
				$(".modal_loading").toggle(false);
			} else if (data == "error04") {
				// ペナルティを受けているユーザーからの削除依頼の場合
				alert("ペナルティ中なので、削除依頼はできません");
				$(".modal_loading").toggle(false);
			} else if (data == "error05") {
				// 1日の削除依頼件数（99件）以上の場合
				alert("一日の削除依頼件数を越えています");
				$(".modal_loading").toggle(false);
			}
			bodyFixedOff();
		},
		error : function() {
			alert("一括削除依頼処理でエラー発生！");
			bodyFixedOff();
		}
	});
}
