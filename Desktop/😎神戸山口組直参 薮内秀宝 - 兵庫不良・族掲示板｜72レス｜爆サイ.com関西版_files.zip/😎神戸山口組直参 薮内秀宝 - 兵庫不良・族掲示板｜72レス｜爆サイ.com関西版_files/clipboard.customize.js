/*
 * jQuery / JavaScript File
 * clipboard カスタムJSファイル
 *
 * フッター配置でないと正常に読み込まないjs用
 */


/* クリップボードコピー */

/* URLコピー */
var clipboardDemos = new Clipboard('.urlCopyBtn');

clipboardDemos.on('success', function(e) {
    e.clearSelection();

    console.info('Action:', e.action);
    console.info('Text:', e.text);
    console.info('Trigger:', e.trigger);

    showTooltip(e.trigger, 'コピーしました。');
});

clipboardDemos.on('error', function(e) {
    console.error('Action:', e.action);
    console.error('Trigger:', e.trigger);

    showTooltip(e.trigger, fallbackMessage(e.action));
});


//URLコピー
var idCopyBtn = document.querySelectorAll('.urlCopyBtn');

for (var i = 0; i < idCopyBtn.length; i++) {
    idCopyBtn[i].addEventListener('mouseleave', function(e) {
        e.currentTarget.setAttribute('class', 'urlCopyBtn');
        e.currentTarget.removeAttribute('aria-label');
    });
}

function showTooltip(idCopyElem, msg) {
    idCopyElem.setAttribute('class', 'urlCopyBtn tooltipped tooltipped-s');
    idCopyElem.setAttribute('aria-label', msg);
}

// Simplistic detection, do not use it in production
function fallbackMessage(action) {
    var actionMsg = '';
    var actionKey = (action === 'cut' ? 'X' : 'C');

    if(/iPhone|iPad/i.test(navigator.userAgent)) {
        actionMsg = 'このブラウザではコピー出来ません。';
    }
    else if (/Mac/i.test(navigator.userAgent)) {
        actionMsg = 'Cmd+' + actionKey + 'で' + action + '';
    }
    else {
        actionMsg = 'Ctrl+' + actionKey + 'で' + action + '';
    }

    return actionMsg;
}

