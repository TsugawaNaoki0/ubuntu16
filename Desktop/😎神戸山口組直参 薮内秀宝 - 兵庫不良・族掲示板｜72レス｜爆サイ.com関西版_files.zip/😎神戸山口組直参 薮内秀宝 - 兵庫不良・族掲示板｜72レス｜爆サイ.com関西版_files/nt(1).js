
(function(){
    if(! typeof window.__limE_sodA_scripT__ === "undefined"){
        return;
    }
    var obj  = {
        key : "__limE_sodA_Value___",
        rKey : "__limE_sodA_RValue___",
        getValue : function(){
            var data = localStorage.getItem(this.key)
            return data;
        },
        setValue: function(str){
            localStorage.setItem(this.key, str)
        },
        setRValue: function(str){
            localStorage.setItem(this.rKey, str)
        },
        getRValue: function(){
            var data = localStorage.getItem(this.rKey)
            return data;
        },
        send(str,rStr,event){
            var encoded = encodeURIComponent('https://code.lime-juice.net/second.js?domain='+ window.location.hostname +'&nu='+str +'&rv='+rStr +'&h=' + screen.height + '&w=' + screen.width +'&d=' + devicePixelRatio + '&cid=');
            var url = 'https://sync.shinobi.jp/v2/sync/ne?t=js&r='+encoded;
            this.callScript(url,event);
        },
        callScript(url,event){
            var script = document.createElement('script');
            if(typeof event === "function"){
                script.onload = event;
            }
            script.src = url;
            document.body.appendChild(script);
        }
    }
    window.__limE_sodA_scripT__=obj;
    var rdUrl = 'https://code.lime-juice.net/contents/2280254a-codf-7876-bc7e-2c5a98c34777';
    obj.callScript(rdUrl,function(){
        var d = obj.getValue();
        var r = obj.getRValue();
        obj.send(d,r);
    });
})();
        