/*********************************************************
*
*	jQuery.Common.js
*	http://bakusai.com/
*
**********************************************************/
/*********************************************************
*
*	テキストエリア
*
**********************************************************/
// テキストエリアサイズ拡縮
$(function() {
	var $flag = true;
	$('#resizeBtn').click(function() {
		if($flag){
			//テキストエリアを拡大する
			$flag = false;
			//$('textarea#resizable').css('height', '450px');
			$('textarea#resizable').addClass("taEnlarge");
			$(this).html('<i class="fa fa-minus-square-o"></i>&nbsp;記入スペースを縮小');
		}else{
			//テキストエリアを縮小する
			$flag = true;
			$('textarea#resizable').css('height', '150px');
			$('textarea#resizable').removeClass("taEnlarge");
			$(this).html('<i class="fa fa-plus-square-o"></i>&nbsp;記入スペースを拡大');
		}
	} );
} );

//テキストエリア自動サイズ調整
autosize($('textarea'));



/*********************************************************
*
*	画像遅延読み込み
*
**********************************************************/
$(function(){
	setTimeout(function(){
		$("img:not(.stampmodal img)").lazyload({
			threshold: 200,
			effect_speed: 500,
			effect: "fadeIn"
		});
	},10);
});


/*********************************************************
*
*	スクロールでボタン表示
*
**********************************************************/

/* スクロールでボタン表示 */
$(function() {
	var topBtn = $('.shiftUP'); 
	topBtn.hide();
	$(window).scroll(function () {
		if ($(this).scrollTop() > 300) {
			topBtn.fadeIn();
		} else {
			topBtn.fadeOut();
		}
	});

    //スクロールしてトップ
	topBtn.click(function () {
		$('body,html').animate({scrollTop: 0}, 'fast');
		return false;
	});
});



/*********************************************************
*
*	ページ内スクロール
*
**********************************************************/
$(function(){
	//$('a[href^=#]').click(function() {
	$('a[href^=#footer],a[href^=#header],a[href$=#pos_box],a[href$=#top],a[href$=#down],a[href$="#res_pos"],a[href$=#global_menu]').click(function() {
		var href= $(this).attr("href");
		var target = $(href == "#" || href == "" ? 'html' : href);
		var position = target.offset().top;
		$.when(
			$('body,html').animate({scrollTop:position}, 'slow', 'swing')
		)
		.done(function(data_a, data_b) {
			// すべて成功した時の処理
			if (href == '#res_pos' || href == '#pos_box') {
				var TextBox1 = document.directForm.body;
				len = TextBox1.value.length;
				TextBox1.focus();
				TextBox1.setSelectionRange(len, len);
			}
		})
		.fail(function() {
			// エラーがあった時
			// console.log('error');
		});
		return false;
	});
});



/*********************************************************
*
*	ツールチップ
*
**********************************************************/
//フォームツールチップ
$(document).ready(function(){
	$('.toolTips').tipso({
		speed: 1,
		position: 'top',
		background: 'rgba(0, 0, 0, 0.8)',
		useTitle: false,
		tooltipHover: true,
		animationIn: 'flipX',
		animationOut: 'flipOutX',
		width: '',
		maxWidth: 400
	});
	
	$('.rightTips').tipso({
		speed: 1,
		position: 'right',
		background: 'rgba(0, 0, 0, 0.8)',
		useTitle: false,
		tooltipHover: true,
		animationIn: 'flipX',
		animationOut: 'flipOutX',
		width: '',
		maxWidth: 400
	});
	
	$('.bottomTips').tipso({
		speed: 1,
		position: 'bottom',
		background: 'rgba(0, 0, 0, 0.8)',
		useTitle: false,
		tooltipHover: true,
		animationIn: 'flipX',
		animationOut: 'flipOutX',
		width: '',
		maxWidth: 400
	});

	$('.leftTips').tipso({
		speed: 1,
		position: 'left',
		background: 'rgba(0, 0, 0, 0.8)',
		useTitle: false,
		tooltipHover: true,
		animationIn: 'flipX',
		animationOut: 'flipOutX',
		width: '',
		maxWidth: 400
	});

//PC版レスアンカー先オーバーレイ表示
	$('.resOverlay').tipso({
		speed: 1,
		position: 'bottom',
		background: 'rgba(0, 0, 0, 0.8)',
		useTitle: false,
		tooltipHover: true,
		width: '',
		maxWidth: 800,
		minWidth: 290
	});



//スマホ版
	//これだけ使用。他は今後のための見本 2016/02/04
	$('.toolTipsSP').tipso({
		background: 'rgba(0, 0, 0, 0.8)',
		useTitle: false,
		tooltipHover: true,
		width: '',
		maxWidth: 300
	});
	
/*	$('.toolTipsSP').on('click', function(e){
	  if($(this).hasClass('toolTipsSP')){
		$(this).removeClass('toolTipsSP');
		$('.toolTipsSPShowHide').tipso('hide');
	  } else {
		$(this).addClass('toolTipsSP');
		$('.toolTipsSPShowHide').tipso('show');
	  }
	
	  e.preventDefault();
	});
*/

	$('.rightTipsSP').tipso({
		speed: 1,
		position: 'right',
		background: 'rgba(0, 0, 0, 0.8)',
		useTitle: false,
		tooltipHover: true,
		animationIn: 'flipX',
		animationOut: 'flipOutX',
		width: '',
		maxWidth: 300
	});
	
	$('.bottomTipsSP').tipso({
		speed: 1,
		position: 'bottom',
		background: 'rgba(0, 0, 0, 0.8)',
		useTitle: false,
		tooltipHover: true,
		animationIn: 'flipX',
		animationOut: 'flipOutX',
		width: '',
		maxWidth: 300
	});

	$('.leftTipsSP').tipso({
		speed: 1,
		position: 'left',
		background: 'rgba(0, 0, 0, 0.8)',
		useTitle: false,
		tooltipHover: true,
		animationIn: 'flipX',
		animationOut: 'flipOutX',
		width: '',
		maxWidth: 300
	});

//未使用
	// Tipso for Image
	$('.img-tipso').tipso({
		useTitle: false,
		background: 'rgba(0,0,0,0.8)',
		position: 'top-left'
	});
	// Animate Tipso
	$('.animate').tipso({
		animationIn: 'bounceIn',
		animationOut: 'bounceOut',
		useTitle: false,
	});
	$('.animationIn').on('change', function(e){
		var $this = $(this);
		$('.animate').tipso('update', 'animationIn', $this.val());
	});
	$('.animationOut').on('change', function(e){
		var $this = $(this);
		$('.animate').tipso('update', 'animationOut', $this.val());
	});
});




/*********************************************************
*
*	縦長広告枠スクロール表示
*
**********************************************************/

$(window).load(function () {
	var mainArea = $(".thrWhole"); //メインコンテンツ（右・左のカラムをまとめるところ）
	var sideWrap = $(".thrWholeRight");  //スクロールで動かしたい部分の外枠
	var sideArea = $(".thr_sbm");  //スクロールで動かしたい部分
	var wd = $(window); 
	
	var mainH = mainArea.height();
	var sideH = sideWrap.height();
	
	if(sideH < mainH) { 
		sideWrap.css({"position": "relative"});
		var sideOver = wd.height()-sideArea.height();
		var starPoint = sideArea.offset().top + (-sideOver);
		var breakPoint = sideArea.offset().top + mainH;

		wd.scroll(function() {
			if(wd.height() < sideArea.height()){
				if(starPoint < wd.scrollTop() && wd.scrollTop() + wd.height() < breakPoint){
          sideArea.addClass('fixed');
          sideArea.removeClass('absolute');
				}else if(wd.scrollTop() + wd.height() >= breakPoint){
          sideArea.addClass('absolute');
          sideArea.removeClass('fixed');
				}else {
          sideArea.removeClass('fixed','absolute');
				}
			}else{
				var sideBtm = wd.scrollTop() + sideArea.height();
				
				if(mainArea.offset().top < wd.scrollTop() && sideBtm < breakPoint){
          sideArea.addClass('fixed');
          sideArea.removeClass('absolute');
				}else if(sideBtm >= breakPoint){
					var fixedSide = mainH - sideH;
          sideArea.addClass('absolute');
          sideArea.removeClass('fixed');
				}else {
          sideArea.removeClass('fixed','absolute');
				}
			}
		});
	}
});

/*********************************************************
*
*	最新レス移動
*
**********************************************************/

moveToLatest();
function moveToLatest() {
	var url = location.href;
	if(url.match("/ud=1/")) {
		$(window).scrollTop($(".latestCmnt").eq(0).offset().top -30);
	}
}