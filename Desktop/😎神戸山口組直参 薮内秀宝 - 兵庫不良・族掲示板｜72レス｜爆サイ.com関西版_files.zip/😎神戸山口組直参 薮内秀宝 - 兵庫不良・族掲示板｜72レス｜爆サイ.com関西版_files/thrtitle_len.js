$(window).on('load resize', function(){
    var thr_pager_len = $('#thr_pager').outerWidth(true);
    var thr_num_len = $('.thr_title_num').outerWidth(true);
    thr_pager_len = thr_pager_len - 95 - thr_num_len;
    $( ".title_overflow" ).css( "width" , thr_pager_len );
});